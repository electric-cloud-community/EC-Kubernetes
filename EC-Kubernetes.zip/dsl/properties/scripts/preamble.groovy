$[/myProject/scripts/Logger]
$[/myProject/scripts/BaseClient]
$[/myProject/scripts/EFClient]
$[/myProject/scripts/KubernetesClient]

